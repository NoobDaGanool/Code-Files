﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace Mails
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        OpenFileDialog open = new OpenFileDialog();
        private void btnMail_Click(object sender, EventArgs e)
        {
            try
            {
                MailMessage mail = new MailMessage("nabsterguy122@gmail.com", "tshepotloujr@gmail.com");
                SmtpClient server = new SmtpClient();

                server.Port = 25;
                server.UseDefaultCredentials = false;
                server.DeliveryMethod = SmtpDeliveryMethod.Network;
                server.Host = "smtp.gmail.com";
                server.Timeout = 10000;
                server.EnableSsl = true;
                server.Credentials = new NetworkCredential("nabsterguy122@gmail.com", "Church21TT");

                mail.Subject = "Just a Test";
                mail.Body = "This is just a mail test, well, here goes nothing !!";
                if (!string.IsNullOrEmpty(open.FileName))
                {
                    mail.Attachments.Add(new Attachment(open.FileName));
                }
                mail.BodyEncoding = UTF8Encoding.UTF8;

                server.Send(mail);
                MessageBox.Show("Message Successfully delivered");
            }
            catch(SmtpException ex)
            {
                //MessageBox.Show(ex.Message.ToString());
                txtMail.Text = ex.Message.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            open.ShowDialog();
        }
    }
}
